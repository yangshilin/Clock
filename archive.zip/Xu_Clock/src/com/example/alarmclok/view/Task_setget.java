package com.example.alarmclok.view;

public class Task_setget {
/**
 * ��������
 */	
	int beijing;
	int bofang;
	String title;
	String nandu;
	int xingji;
	int xuanzhe;
	public int getBeijing() {
		return beijing;
	}
	public void setBeijing(int beijing) {
		this.beijing = beijing;
	}
	public int getBofang() {
		return bofang;
	}
	public void setBofang(int bofang) {
		this.bofang = bofang;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getNandu() {
		return nandu;
	}
	public void setNandu(String nandu) {
		this.nandu = nandu;
	}
	public int getXingji() {
		return xingji;
	}
	public void setXingji(int xingji) {
		this.xingji = xingji;
	}
	public int getXuanzhe() {
		return xuanzhe;
	}
	public void setXuanzhe(int xuanzhe) {
		this.xuanzhe = xuanzhe;
	}


	
}
