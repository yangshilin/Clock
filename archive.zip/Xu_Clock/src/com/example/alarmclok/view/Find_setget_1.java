package com.example.alarmclok.view;

public class Find_setget_1 {
	/**
	 *��������
	 */
	String title;
	String time;
	String userQuantity;
	String praiseQuantity;
	String commentQuantity;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getUserQuantity() {
		return userQuantity;
	}
	public void setUserQuantity(String userQuantity) {
		this.userQuantity = userQuantity;
	}
	public String getPraiseQuantity() {
		return praiseQuantity;
	}
	public void setPraiseQuantity(String praiseQuantity) {
		this.praiseQuantity = praiseQuantity;
	}
	public String getCommentQuantity() {
		return commentQuantity;
	}
	public void setCommentQuantity(String commentQuantity) {
		this.commentQuantity = commentQuantity;
	}

}
