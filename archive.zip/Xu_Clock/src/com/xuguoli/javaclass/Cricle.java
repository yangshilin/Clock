package com.xuguoli.javaclass;

public class Cricle {
	int iamgeId;
	String usename;
	String fromphone;
	int button;
	String zuoyong;
	int player;
	String time;
	int colltect;
	String numb;
	int message;
	String pinglun;

	public int getIamgeId() {
		return iamgeId;
	}

	public void setIamgeId(int iamgeId) {
		this.iamgeId = iamgeId;
	}

	public String getUsename() {
		return usename;
	}

	public void setUsename(String usename) {
		this.usename = usename;
	}

	public String getFromphone() {
		return fromphone;
	}

	public void setFromphone(String fromphone) {
		this.fromphone = fromphone;
	}

	public int getButton() {
		return button;
	}

	public void setButton(int button) {
		this.button = button;
	}

	public String getZuoyong() {
		return zuoyong;
	}

	public void setZuoyong(String zuoyong) {
		this.zuoyong = zuoyong;
	}

	public int getPlayer() {
		return player;
	}

	public void setPlayer(int player) {
		this.player = player;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getColltect() {
		return colltect;
	}

	public void setColltect(int colltect) {
		this.colltect = colltect;
	}

	public String getNumb() {
		return numb;
	}

	public void setNumb(String numb) {
		this.numb = numb;
	}

	public int getMessage() {
		return message;
	}

	public void setMessage(int message) {
		this.message = message;
	}

	public String getPinglun() {
		return pinglun;
	}

	public void setPinglun(String pinglun) {
		this.pinglun = pinglun;
	}

}
