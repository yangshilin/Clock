package com.xuguoli.acyivity;

import com.example.clock.R;

import android.app.Activity;
import android.os.Bundle;

public class Add extends Activity {
 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add);
	}
	
}
